package fr.uha.ensisa.web.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import fr.uha.ensisa.web.model.Travel;

@Controller
public class WebController {
	
	private Integer[] meansNumbers = {0,0,0,0,0,0,0};
	private List<Travel> travels = new ArrayList<Travel>();
	private int index = 2;
	
	public int getIndex(){
		return index++;
	}
	
	public WebController() {
		initTravel();
	}

	private void initTravel(){
		Travel t = new Travel("Vacances en Italie", "Rome", "23/05/17", "16/08/2018", "voiture");
		t.image();
		this.travels.add(t);
		
	}
	
	@RequestMapping(value="/travel/means", method=RequestMethod.GET)
	public ResponseEntity<Integer[]>countMeans() {
		for(int i=0;i<7;i++) this.meansNumbers[i] = 0;
		for(Travel travel : this.travels){
			if(travel.getTransportMean().equals("avion")) this.meansNumbers[0]++;
			if(travel.getTransportMean().equals("bateau")) this.meansNumbers[1]++;
			if(travel.getTransportMean().equals("bus")) this.meansNumbers[2]++;
			if(travel.getTransportMean().equals("moto")) this.meansNumbers[3]++;
			if(travel.getTransportMean().equals("train")) this.meansNumbers[4]++;
			if(travel.getTransportMean().equals("velo")) this.meansNumbers[5]++;
			if(travel.getTransportMean().equals("voiture")) this.meansNumbers[6]++;
		}
		return new ResponseEntity<Integer[]>(this.meansNumbers, HttpStatus.OK);
	}
	
	@RequestMapping(value="/travel/createTravel", method=RequestMethod.POST)
	public ResponseEntity<List<Travel>> createTravel(@RequestBody Travel newTravel) {
		newTravel.setId(getIndex());
		newTravel.image();
		this.travels.add(newTravel);
		this.countMeans();
		return new ResponseEntity<List<Travel>>(this.travels, HttpStatus.OK);
	}
	
	@RequestMapping(value="/travel/getTravels", method=RequestMethod.GET)
	public ResponseEntity<List<Travel>> getTravels() {
		return new ResponseEntity<List<Travel>>(this.travels, HttpStatus.OK);
	}
	
	@RequestMapping(value="/travel/editTravel/{id}", method=RequestMethod.PUT)
	public ResponseEntity<List<Travel>> editTravel(@PathVariable int id, @RequestBody Travel editedTravel) {
		editedTravel.setId(id);
		editedTravel.image();
		int i=0;
		for(Travel temp : travels){
			if (temp.getId()==id){
				this.travels.set(i, editedTravel);
			}
			i++;
		}
		this.countMeans();
		return new ResponseEntity<List<Travel>>(travels, HttpStatus.OK);
	}
	
	@RequestMapping(value="travel/deleteTravel/{id}", method=RequestMethod.GET)
	public ResponseEntity<List<Travel>> deleteTravel(@PathVariable int id) {
		Travel tbis = new Travel();
		for(Travel temp : this.travels){
			if (temp.getId()==id){
				tbis=temp;
			}
		}
		this.travels.remove(tbis);
		this.countMeans();
		return new ResponseEntity<List<Travel>>(this.travels, HttpStatus.OK);
	}
	
	
}
