package fr.uha.ensisa.web.model;

import java.awt.Image;

public class Travel {

	private String name;
	private String place;
	private String beginningDate;
	private String endDate;
	private String transportMean;
	private int id;
	private boolean edit = false;
	
	private String plane = "/images/avion.png";
	private String boat = "/images/bateau.png";
	private String bus = "/images/bus.png";
	private String motorbike = "/images/moto.png";
	private String train = "/images/train.png";
	private String bike = "/images/velo.png";
	private String car = "/images/voiture.png";
	private String image = "";

	public Travel(String name, String place, String beginningDate, String endDate, String transportMean) {
		this.name = name;
		this.place = place;
		this.beginningDate = beginningDate;
		this.endDate = endDate;
		this.transportMean = transportMean;
		this.id = id;
	}
	
	public Travel(){
		this.name = new String();
		this.place = new String();
		this.beginningDate = new String();
		this.endDate = new String();
		this.transportMean = new String();
		this.id = 0;
	}
	
	public void image(){
		if(this.transportMean.equals("avion")) this.image = this.plane;
		if(this.transportMean.equals("bateau")) this.image = this.boat;
		if(this.transportMean.equals("bus")) this.image = this.bus;
		if(this.transportMean.equals("moto")) this.image = this.motorbike;
		if(this.transportMean.equals("train")) this.image = this.train;
		if(this.transportMean.equals("velo")) this.image = this.bike;
		if(this.transportMean.equals("voiture")) this.image = this.car;
	}
	
	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getBeginningDate() {
		return beginningDate;
	}
	public void setBeginningDate(String beginningDate) {
		this.beginningDate = beginningDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getTransportMean() {
		return transportMean;
	}
	public void setTransportMean(String transportMean) {
		this.transportMean = transportMean;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
}
