(function(){

'use strict';
	
angular.module('travelController',[]);

var app = angular.module('store', ['travelController']);

//app.controller('TravelController', function(){
//
//
//});

//var voyage = {
//        name: "Voyage France",
//        place: "France",
//        beginningDate: "23/08/2017",
//        endDate: "30/02/2017",
//        transportMean: "Avion",
//		}
//
//
//var voyages = [{
//            name: "Voyage Amerique",
//            place: "Am�rique",
//            beginningDate: "10/02/2017",
//            endDate: "17/02/2017",
//            transportMean: "Avion",
//            },
//            {
//            name: "Voyage Italie",
//            place: "Italie",
//            beginningDate: "15/03/2017",
//            endDate: "25/03/2017",
//            transportMean: "Train",
//            }
//           ];

})();