(function(){
	
	'use strict'
	
angular.module('travelController', [])
	.controller('travelCtrl',['$scope','$http','$window', function($scope,$http,$window){
		
		$scope.editedTravel = {};
		$scope.meansNumbers = [0,0,0,0,0,0,0];
		
		$scope.reload = function() {
			   $window.location.reload();
		};
		
		$scope.countMeans = function(){
			$http.get('/travel/means').then(function(response){
				$scope.meansNumbers = response.data;
			});
		};
		
		$http.get('/travel/means').then(function(response){
			$scope.meansNumbers = response.data;
		});
		
		
		
		$scope.createTravel = function(){
			$http.post("/travel/createTravel", $scope.newTravel).then(function(response){
				$scope.travels = response.data;
				$scope.newTravel = null;
			});
		};
		
		$scope.editTravel = function(id){
			$http.put('/travel/editTravel/' + id, $scope.editedTravel).then(function(response){
				$scope.travels = response.data;
				$scope.editedTravel = {};
			});
		};
	
		$scope.deleteTravel = function(id){
			$http.get('travel/deleteTravel/'+id).then(function(response){
				$scope.travels = response.data;
			});
		};
	
		$http.get("/travel/getTravels").then(function(response){
			$scope.travels = response.data;
		});
			
	}]);

})();
